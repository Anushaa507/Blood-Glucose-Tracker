const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function parts(dateString) {
  const [y, m, d] = dateString.split('-').map(Number);
  return { y, m, d };
}

// "2026-10-15" -> "15 Oct 2026"
export function formatDate(dateString) {
  const { y, m, d } = parts(dateString);
  return `${d} ${MONTHS[m - 1]} ${y}`;
}

// ("2026-10-01", "2026-10-15") -> "1 Oct – 15 Oct 2026"; same day -> "15 Oct 2026"
export function formatRange(from, to) {
  if (from === to) return formatDate(from);
  const a = parts(from);
  return `${a.d} ${MONTHS[a.m - 1]} – ${formatDate(to)}`;
}

// "2026-10-15" -> "15 Oct" (short label for chart axis)
export function formatShort(dateString) {
  const { m, d } = parts(dateString);
  return `${d} ${MONTHS[m - 1]}`;
}

// Today's date in the browser's own timezone, as "YYYY-MM-DD".
export function todayString(now = new Date()) {
  const pad = (n) => String(n).padStart(2, '0');
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
}
