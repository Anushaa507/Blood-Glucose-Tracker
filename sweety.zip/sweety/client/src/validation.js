import { MIN_VALUE, MAX_VALUE } from './constants';

// Client-side checks, mirroring the server so users get instant feedback.
// The server still re-checks everything, and also enforces the rules that need
// the database ("one per slot per day", "max 4 per day").
// Returns an object of { field: message } (empty when everything is valid).
export function validateReadingForm({ value, slot, date }, today) {
  const errors = {};

  const text = String(value ?? '').trim();
  if (text === '') {
    errors.value = 'Please enter a glucose value.';
  } else {
    const n = Number(text);
    if (!Number.isInteger(n) || n < MIN_VALUE || n > MAX_VALUE) {
      errors.value = `Value must be between ${MIN_VALUE} and ${MAX_VALUE} mg/dl.`;
    }
  }

  if (!slot) errors.slot = 'Please choose a time slot.';

  if (!date) errors.date = 'Please choose a date.';
  else if (date > today) errors.date = 'Date cannot be in the future.';

  return errors;
}
