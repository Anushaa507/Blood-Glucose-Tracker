import { useCallback, useEffect, useState } from 'react';
import { api } from '../api';
import { useAuth } from '../AuthContext';
import MonthChart from '../components/MonthChart';
import ReadingForm from '../components/ReadingForm';
import ReadingsList from '../components/ReadingsList';
import ReportCard from '../components/ReportCard';
import { SLOT_LABELS } from '../constants';
import { formatDate, todayString } from '../utils/format';

const PAGE_SIZE = 10;

export default function Dashboard() {
  const { user, logout } = useAuth();
  const today = todayString();

  const [selectedDate, setSelectedDate] = useState(today);
  const [reports, setReports] = useState(null);
  const [reportsError, setReportsError] = useState('');

  const [readings, setReadings] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [listError, setListError] = useState('');

  const [editing, setEditing] = useState(null); // reading being edited, or null
  const [notice, setNotice] = useState('');

  const loadReports = useCallback(async () => {
    try {
      setReports(await api.getReports(selectedDate));
      setReportsError('');
    } catch (err) {
      setReportsError(err.message);
    }
  }, [selectedDate]);

  const loadReadings = useCallback(async () => {
    try {
      const data = await api.listReadings({ page, limit: PAGE_SIZE });
      // If the last item on a page was deleted, step back one page.
      if (data.data.length === 0 && page > 1) return setPage(page - 1);
      setReadings(data.data);
      setTotalPages(data.totalPages);
      setListError('');
    } catch (err) {
      setListError(err.message);
    }
  }, [page]);

  useEffect(() => {
    loadReports();
  }, [loadReports]);

  useEffect(() => {
    loadReadings();
  }, [loadReadings]);

  const refresh = () => Promise.all([loadReports(), loadReadings()]);

  // Throwing here shows the server's message inside the form.
  async function handleAdd(payload) {
    await api.createReading(payload);
    setNotice('Reading saved.');
    setSelectedDate(payload.date); // show the report for the day just logged
    setPage(1);
    await refresh();
  }

  async function handleEdit(payload) {
    await api.updateReading(editing.id, payload);
    setEditing(null);
    setNotice('Reading updated.');
    await refresh();
  }

  async function handleDelete(reading) {
    const label = `${SLOT_LABELS[reading.slot]} on ${formatDate(reading.date)}`;
    if (!window.confirm(`Delete the ${label} reading?`)) return;
    try {
      await api.deleteReading(reading.id);
      setNotice('Reading deleted.');
      await refresh();
    } catch (err) {
      setListError(err.message);
    }
  }

  return (
    <div className="layout">
      <header className="topbar">
        <h1 className="brand">Sweety</h1>
        <div className="topbar-right">
          <span className="muted">Hi, {user.name}</span>
          <button className="btn small" onClick={logout}>
            Log out
          </button>
        </div>
      </header>

      <main>
        {notice && (
          <p className="notice" role="status" onAnimationEnd={() => setNotice('')}>
            {notice}
          </p>
        )}

        <section className="card">
          <h2>{editing ? 'Edit reading' : 'Add a reading'}</h2>
          {editing ? (
            <ReadingForm
              key={editing.id}
              initial={editing}
              submitLabel="Update reading"
              onSubmit={handleEdit}
              onCancel={() => setEditing(null)}
            />
          ) : (
            <ReadingForm onSubmit={handleAdd} />
          )}
        </section>

        <section>
          <div className="section-head">
            <h2>Reports</h2>
            <label className="inline">
              Report date
              <input
                type="date"
                value={selectedDate}
                max={today}
                onChange={(e) => e.target.value && setSelectedDate(e.target.value)}
              />
            </label>
          </div>

          {reportsError && (
            <p className="error" role="alert">
              {reportsError}
            </p>
          )}

          {reports && (
            <>
              <div className="report-grid">
                <ReportCard title="Daily" report={reports.daily} showReadings />
                <ReportCard title="Month to date" report={reports.monthToDate} />
                <ReportCard title="Previous month" report={reports.previousMonth} />
              </div>

              <section className="card">
                <h3>This month&apos;s trend</h3>
                <MonthChart readings={reports.monthToDate.readings} />
              </section>
            </>
          )}
        </section>

        <section className="card">
          <h2>All readings</h2>
          {listError && (
            <p className="error" role="alert">
              {listError}
            </p>
          )}
          <ReadingsList
            readings={readings}
            page={page}
            totalPages={totalPages}
            onPage={setPage}
            onEdit={(r) => {
              setEditing(r);
              setNotice('');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onDelete={handleDelete}
          />
        </section>
      </main>
    </div>
  );
}
