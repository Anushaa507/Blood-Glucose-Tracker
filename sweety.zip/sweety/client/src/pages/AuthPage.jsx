import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../AuthContext';

// One page for both "Log in" and "Sign up".
export default function AuthPage({ mode }) {
  const isRegister = mode === 'register';
  const { login, register } = useAuth();

  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const update = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');

    if (isRegister && !form.name.trim()) return setError('Please enter your name.');
    if (!form.email.trim()) return setError('Please enter your email address.');
    if (isRegister && form.password.length < 8) {
      return setError('Password must be at least 8 characters.');
    }
    if (!isRegister && !form.password) return setError('Please enter your password.');

    setSubmitting(true);
    try {
      if (isRegister) await register(form.name.trim(), form.email.trim(), form.password);
      else await login(form.email.trim(), form.password);
      // On success the router redirects to the dashboard.
    } catch (err) {
      setError(err.message);
      setSubmitting(false);
    }
  }

  return (
    <main className="auth-page">
      <div className="card auth-card">
        <h1 className="brand">Sweety</h1>
        <p className="muted">Track your blood glucose, one reading at a time.</p>

        <h2>{isRegister ? 'Create your account' : 'Welcome back'}</h2>

        <form onSubmit={handleSubmit} noValidate>
          {isRegister && (
            <label>
              Name
              <input value={form.name} onChange={update('name')} autoComplete="name" />
            </label>
          )}
          <label>
            Email
            <input
              type="email"
              value={form.email}
              onChange={update('email')}
              autoComplete="email"
            />
          </label>
          <label>
            Password
            <input
              type="password"
              value={form.password}
              onChange={update('password')}
              autoComplete={isRegister ? 'new-password' : 'current-password'}
            />
            {isRegister && <small className="muted">At least 8 characters.</small>}
          </label>

          {error && (
            <p className="error" role="alert">
              {error}
            </p>
          )}

          <button type="submit" className="btn primary" disabled={submitting}>
            {submitting ? 'Please wait…' : isRegister ? 'Sign up' : 'Log in'}
          </button>
        </form>

        <p className="muted switch">
          {isRegister ? (
            <>
              Already have an account? <Link to="/login">Log in</Link>
            </>
          ) : (
            <>
              New here? <Link to="/register">Create an account</Link>
            </>
          )}
        </p>
      </div>
    </main>
  );
}
