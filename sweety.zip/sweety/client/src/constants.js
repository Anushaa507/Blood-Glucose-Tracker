// Same slots, in the same order, as the server.
export const SLOTS = [
  { value: 'morning', label: 'Morning (fasting)' },
  { value: 'after_breakfast', label: 'After breakfast' },
  { value: 'after_lunch', label: 'After lunch' },
  { value: 'after_dinner', label: 'After dinner' },
];

export const SLOT_LABELS = Object.fromEntries(SLOTS.map((s) => [s.value, s.label]));

export const MIN_VALUE = 40;
export const MAX_VALUE = 600;
