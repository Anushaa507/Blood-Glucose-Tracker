import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it, vi } from 'vitest';
import ReadingForm from './ReadingForm';
import { todayString } from '../utils/format';

const setup = (onSubmit = vi.fn().mockResolvedValue()) => {
  render(<ReadingForm onSubmit={onSubmit} />);
  return {
    onSubmit,
    user: userEvent.setup(),
    value: () => screen.getByLabelText(/glucose/i),
    slot: () => screen.getByLabelText(/time slot/i),
    date: () => screen.getByLabelText(/date/i),
    submit: () => screen.getByRole('button', { name: /save reading/i }),
  };
};

describe('ReadingForm', () => {
  it('asks for a value when it is empty', async () => {
    const { user, submit, onSubmit } = setup();
    await user.click(submit());

    expect(screen.getByText('Please enter a glucose value.')).toBeInTheDocument();
    expect(screen.getByText('Please choose a time slot.')).toBeInTheDocument();
    expect(onSubmit).not.toHaveBeenCalled();
  });

  it.each([['39'], ['601'], ['100.5']])('rejects %s as out of range', async (bad) => {
    const { user, value, slot, submit, onSubmit } = setup();
    await user.selectOptions(slot(), 'morning');
    await user.type(value(), bad);
    await user.click(submit());

    expect(screen.getByText('Value must be between 40 and 600 mg/dl.')).toBeInTheDocument();
    expect(onSubmit).not.toHaveBeenCalled();
  });

  it('rejects a date in the future', async () => {
    const { user, value, slot, date, submit, onSubmit } = setup();
    await user.selectOptions(slot(), 'morning');
    await user.type(value(), '120');
    fireEvent.change(date(), { target: { value: '2999-01-01' } });
    await user.click(submit());

    expect(screen.getByText('Date cannot be in the future.')).toBeInTheDocument();
    expect(onSubmit).not.toHaveBeenCalled();
  });

  it('submits a valid reading as numbers and clears the form', async () => {
    const { user, value, slot, submit, onSubmit } = setup();
    await user.selectOptions(slot(), 'after_lunch');
    await user.type(value(), '142');
    await user.click(submit());

    await waitFor(() =>
      expect(onSubmit).toHaveBeenCalledWith({
        date: todayString(),
        slot: 'after_lunch',
        value: 142,
      })
    );
    await waitFor(() => expect(value()).toHaveValue(null)); // number input emptied
  });

  it('shows the server message when the API rejects the reading', async () => {
    const message = 'You already have an After lunch reading for this date.';
    const { user, value, slot, submit } = setup(vi.fn().mockRejectedValue(new Error(message)));
    await user.selectOptions(slot(), 'after_lunch');
    await user.type(value(), '150');
    await user.click(submit());

    expect(await screen.findByRole('alert')).toHaveTextContent(message);
  });
});
