import {
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ReferenceArea,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { SLOTS } from '../constants';
import { formatShort } from '../utils/format';

const COLORS = {
  morning: '#2563eb',
  after_breakfast: '#d97706',
  after_lunch: '#059669',
  after_dinner: '#c026d3',
};

// [{ date, slot, value }] -> [{ date, morning: 95, after_lunch: 140, ... }]
export function toChartData(readings) {
  const byDate = new Map();
  readings.forEach((r) => {
    if (!byDate.has(r.date)) byDate.set(r.date, { date: r.date });
    byDate.get(r.date)[r.slot] = r.value;
  });
  return [...byDate.values()].sort((a, b) => (a.date < b.date ? -1 : 1));
}

// Bonus: line chart of this month's readings, one line per time slot.
export default function MonthChart({ readings }) {
  const data = toChartData(readings);

  if (data.length === 0) {
    return <p className="empty">Add readings this month to see your trend chart.</p>;
  }

  return (
    <div className="chart" role="img" aria-label="Line chart of readings this month">
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data} margin={{ top: 8, right: 16, bottom: 0, left: -8 }}>
          <CartesianGrid strokeDasharray="3 3" />
          {/* Shaded band: a commonly used "in range" window, 70-180 mg/dl */}
          <ReferenceArea y1={70} y2={180} fill="#16a34a" fillOpacity={0.07} />
          <XAxis dataKey="date" tickFormatter={formatShort} />
          <YAxis domain={['dataMin - 10', 'dataMax + 10']} />
          <Tooltip labelFormatter={formatShort} />
          <Legend />
          {SLOTS.map((s) => (
            <Line
              key={s.value}
              type="monotone"
              dataKey={s.value}
              name={s.label}
              stroke={COLORS[s.value]}
              strokeWidth={2}
              dot={{ r: 3 }}
              connectNulls
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
