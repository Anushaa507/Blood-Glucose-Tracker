import { SLOT_LABELS } from '../constants';
import { formatRange } from '../utils/format';

function Stat({ label, value, unit }) {
  return (
    <div className="stat">
      <span className="stat-label">{label}</span>
      <span className="stat-value">
        {value}
        {unit && <small> {unit}</small>}
      </span>
    </div>
  );
}

/**
 * One report: highest, lowest, average and count for a date range.
 * Pass `showReadings` to also list each reading with its slot (daily report).
 */
export default function ReportCard({ title, report, showReadings = false }) {
  const { from, to, stats, readings } = report;

  return (
    <section className="card report-card" aria-label={`${title} report`}>
      <header>
        <h3>{title}</h3>
        <p className="muted">{formatRange(from, to)}</p>
      </header>

      {stats.count === 0 ? (
        <p className="empty">No readings for this period yet.</p>
      ) : (
        <>
          <div className="stats">
            <Stat label="Highest" value={stats.highest} unit="mg/dl" />
            <Stat label="Lowest" value={stats.lowest} unit="mg/dl" />
            <Stat label="Average" value={stats.average.toFixed(1)} unit="mg/dl" />
            <Stat label="Readings" value={stats.count} />
          </div>

          {showReadings && (
            <ul className="reading-list">
              {readings.map((r) => (
                <li key={r.id}>
                  <span>{SLOT_LABELS[r.slot]}</span>
                  <strong>{r.value} mg/dl</strong>
                </li>
              ))}
            </ul>
          )}
        </>
      )}
    </section>
  );
}
