import { useState } from 'react';
import { MAX_VALUE, MIN_VALUE, SLOTS } from '../constants';
import { todayString } from '../utils/format';
import { validateReadingForm } from '../validation';

/**
 * Form used for both adding and editing a reading.
 *  - initial:  { date, slot, value } to pre-fill
 *  - onSubmit: async (payload) => void. If it throws, the message is shown
 *              as the form error (this is how server rules like
 *              "one per slot per day" reach the user).
 *  - onCancel: optional; shows a Cancel button (used when editing)
 */
export default function ReadingForm({ initial, onSubmit, onCancel, submitLabel = 'Save reading' }) {
  const today = todayString();
  const [form, setForm] = useState({
    date: initial?.date || today,
    slot: initial?.slot || '',
    value: initial?.value ?? '',
  });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const update = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  async function handleSubmit(e) {
    e.preventDefault();
    setFormError('');

    const found = validateReadingForm(form, today);
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    setSubmitting(true);
    try {
      await onSubmit({ date: form.date, slot: form.slot, value: Number(form.value) });
      if (!initial) setForm({ ...form, slot: '', value: '' }); // ready for the next reading
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} noValidate aria-label="Reading form">
      <div className="form-row">
        <label>
          Date
          <input type="date" value={form.date} max={today} onChange={update('date')} />
          {errors.date && <span className="field-error">{errors.date}</span>}
        </label>

        <label>
          Time slot
          <select value={form.slot} onChange={update('slot')}>
            <option value="">Choose a slot…</option>
            {SLOTS.map((s) => (
              <option key={s.value} value={s.value}>
                {s.label}
              </option>
            ))}
          </select>
          {errors.slot && <span className="field-error">{errors.slot}</span>}
        </label>

        <label>
          Glucose (mg/dl)
          <input
            type="number"
            inputMode="numeric"
            placeholder={`${MIN_VALUE} – ${MAX_VALUE}`}
            value={form.value}
            onChange={update('value')}
          />
          {errors.value && <span className="field-error">{errors.value}</span>}
        </label>
      </div>

      {formError && (
        <p className="error" role="alert">
          {formError}
        </p>
      )}

      <div className="actions">
        <button type="submit" className="btn primary" disabled={submitting}>
          {submitting ? 'Saving…' : submitLabel}
        </button>
        {onCancel && (
          <button type="button" className="btn" onClick={onCancel}>
            Cancel
          </button>
        )}
      </div>
    </form>
  );
}
