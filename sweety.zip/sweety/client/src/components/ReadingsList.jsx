import { SLOT_LABELS } from '../constants';
import { formatDate } from '../utils/format';

export default function ReadingsList({ readings, page, totalPages, onPage, onEdit, onDelete }) {
  if (!readings.length) {
    return (
      <p className="empty">
        No readings yet. Add your first one above — it only takes a few seconds.
      </p>
    );
  }

  return (
    <>
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Slot</th>
              <th className="num">mg/dl</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {readings.map((r) => (
              <tr key={r.id}>
                <td>{formatDate(r.date)}</td>
                <td>{SLOT_LABELS[r.slot]}</td>
                <td className="num">
                  <strong>{r.value}</strong>
                </td>
                <td className="row-actions">
                  <button className="btn small" onClick={() => onEdit(r)}>
                    Edit
                  </button>
                  <button className="btn small danger" onClick={() => onDelete(r)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="pager">
          <button className="btn small" disabled={page <= 1} onClick={() => onPage(page - 1)}>
            ← Previous
          </button>
          <span className="muted">
            Page {page} of {totalPages}
          </span>
          <button
            className="btn small"
            disabled={page >= totalPages}
            onClick={() => onPage(page + 1)}
          >
            Next →
          </button>
        </div>
      )}
    </>
  );
}
