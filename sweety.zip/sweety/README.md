# Sweety – Blood Glucose Tracker

Sweety lets a diabetes patient record up to **4 blood glucose readings a day** (mg/dl) and view **daily, month-to-date and previous-month reports**.

**Stack:** Node.js + Express API · PostgreSQL · React (Vite) frontend · JWT auth with bcrypt-hashed passwords.

```
sweety/
├── docker-compose.yml        # local PostgreSQL
├── server/                   # Express API
│   ├── db/schema.sql         # database tables
│   ├── src/
│   │   ├── routes/           # auth, readings, reports
│   │   ├── middleware/       # JWT auth, error handling
│   │   ├── utils/            # validation, dates, report maths (pure functions)
│   │   └── scripts/          # migrate.js, seed.js
│   ├── tests/                # unit tests (node:test)
│   └── .env.example
└── client/                   # React frontend
    ├── src/
    └── .env.example
```

## Features

- Sign up / log in. Passwords are hashed with **bcrypt**; users only ever see their own readings.
- Add, view, edit and delete readings (date, time slot, value in mg/dl).
- Validation with clear messages, both in the UI and in the API (the API is the source of truth).
- Reports: highest, lowest, average (1 decimal) and count, with a friendly empty state.
  - **Daily** – the selected date (also lists each reading with its slot)
  - **Month to date** – 1st of the month → selected date
  - **Previous month** – the whole month before the selected date's month
- Bonus included: pagination (`GET /api/readings?page=1&limit=20`), a line chart of the month's readings, `docker-compose.yml` for PostgreSQL, and React Testing Library tests for the reading form.

## Prerequisites

- Node.js 18+ (developed on Node 22)
- PostgreSQL 14+ — or Docker, to run the one in `docker-compose.yml`

## 1. Install

```bash
git clone <your-repo-url> sweety
cd sweety

cd server && npm install
cd ../client && npm install
```

## 2. Set up the database

**Option A – Docker (easiest):**

```bash
docker compose up -d        # from the repo root
```

**Option B – your own PostgreSQL:**

```bash
createdb sweety
# then set DATABASE_URL in server/.env to match your user/password
```

Create the tables and load demo data:

```bash
cd server
cp .env.example .env        # then set JWT_SECRET (see the comment inside)
npm run migrate             # creates the tables (safe to re-run)
npm run seed                # demo user + ~45 days of sample readings
```

Demo login: **demo@sweety.app** / **Demo@1234**

## 3. Run

```bash
# Terminal 1 – API on http://localhost:4000
cd server
npm run dev

# Terminal 2 – frontend on http://localhost:5173
cd client
npm run dev
```

Open http://localhost:5173. In development Vite proxies `/api` to the Express server, so no extra frontend config is needed.

## 4. Run the tests

```bash
cd server && npm test       # validation, date ranges and report calculations
cd client && npm test       # React Testing Library tests for the reading form
```

The server tests use Node's built-in test runner and need no database.

## Environment variables

| File | Variable | Purpose |
|------|----------|---------|
| `server/.env` | `PORT` | API port (default 4000) |
| | `DATABASE_URL` | PostgreSQL connection string |
| | `JWT_SECRET` | Secret used to sign login tokens (required) |
| | `JWT_EXPIRES_IN` | Token lifetime (default `7d`) |
| | `APP_TIMEZONE` | Timezone used to decide what "today" is (default `Asia/Kolkata`) |
| | `CLIENT_ORIGIN` | Frontend URL allowed by CORS |
| `client/.env` | `VITE_API_URL` | Optional API base URL (default `/api`) |

## API overview

All routes except register/login need `Authorization: Bearer <token>`.

| Method | Route | Description |
|--------|-------|-------------|
| POST | `/api/auth/register` | `{ name, email, password }` → `{ token, user }` |
| POST | `/api/auth/login` | `{ email, password }` → `{ token, user }` |
| GET | `/api/auth/me` | Current user |
| GET | `/api/readings?page=1&limit=20` | Your readings, newest first, paginated |
| POST | `/api/readings` | `{ date, slot, value }` |
| PUT | `/api/readings/:id` | Replace a reading |
| DELETE | `/api/readings/:id` | Delete a reading |
| GET | `/api/reports?date=YYYY-MM-DD` | Daily + month-to-date + previous-month reports |

Slots: `morning`, `after_breakfast`, `after_lunch`, `after_dinner`.
Errors come back as `{ "error": "message" }` with a 4xx status.

## Notes

### Assumptions

- **"Today" uses one timezone** (`APP_TIMEZONE`, default `Asia/Kolkata`) on the server, so the "date cannot be in the future" rule is consistent. The browser also limits the date picker to its own local today.
- **Max 4 readings per day** is checked in the API and is also guaranteed by the database: there are exactly 4 slots and a unique constraint on `(user_id, reading_date, slot)`, so concurrent requests can't exceed it.
- Check order on create: a day that already has 4 readings shows "You can add only 4 readings per day."; otherwise a repeated slot shows "You already have an After lunch reading for this date."
- Editing a reading to a date/slot that is already taken gives the same errors; a reading never conflicts with itself.
- "Whole number" means an integer; `100.5` is rejected with the 40–600 message.
- The report date can be today or any past date; a future report date is rejected.
- **Previous month** means the whole calendar month before the *selected date's* month (selected 15 Oct → 1–30 Sep).
- Emails are stored lower-case; passwords must be at least 8 characters.
- The JWT is kept in `localStorage` for simplicity.

### What I would improve with more time

- Store the JWT in an httpOnly cookie, and add rate limiting on login.
- API integration tests against a throwaway test database (the current tests cover the pure logic: validation, date ranges, report maths).
- Per-user timezone instead of one app-wide timezone.
- Colour-code readings as low / in range / high and add CSV/PDF export for doctor visits.
- Caching of report results (Redis) and a reminder job (BullMQ) for days with fewer than 4 readings.
- A doctor role to view assigned patients' reports.

## Screenshots / demo

Add your screenshots or screen recording link here before submitting.
