const { test } = require('node:test');
const assert = require('node:assert/strict');
const {
  monthToDateRange,
  previousMonthRange,
  addDays,
  todayInTimezone,
  isValidDateString,
} = require('../src/utils/dates');
const { computeStats, buildReports } = require('../src/utils/reports');

test('date ranges for 15 Oct 2026 match the assignment example', () => {
  assert.deepEqual(monthToDateRange('2026-10-15'), { from: '2026-10-01', to: '2026-10-15' });
  assert.deepEqual(previousMonthRange('2026-10-15'), { from: '2026-09-01', to: '2026-09-30' });
});

test('previous month handles January (previous year) and leap February', () => {
  assert.deepEqual(previousMonthRange('2026-01-10'), { from: '2025-12-01', to: '2025-12-31' });
  assert.deepEqual(previousMonthRange('2028-03-05'), { from: '2028-02-01', to: '2028-02-29' });
  assert.deepEqual(previousMonthRange('2026-03-05'), { from: '2026-02-01', to: '2026-02-28' });
});

test('addDays crosses month and year boundaries', () => {
  assert.equal(addDays('2026-03-01', -1), '2026-02-28');
  assert.equal(addDays('2026-01-01', -1), '2025-12-31');
});

test('todayInTimezone uses the given timezone', () => {
  const instant = new Date('2026-11-14T20:00:00Z'); // already 15 Nov in India
  assert.equal(todayInTimezone('Asia/Kolkata', instant), '2026-11-15');
  assert.equal(todayInTimezone('UTC', instant), '2026-11-14');
});

test('isValidDateString', () => {
  assert.equal(isValidDateString('2026-10-15'), true);
  assert.equal(isValidDateString('2026-13-01'), false);
  assert.equal(isValidDateString('nope'), false);
});

test('computeStats: highest, lowest, average (1 decimal), count', () => {
  assert.deepEqual(computeStats([100, 150, 200]), {
    count: 3,
    highest: 200,
    lowest: 100,
    average: 150,
  });
  // 100 + 101 + 101 = 302 / 3 = 100.666... -> 100.7
  assert.equal(computeStats([100, 101, 101]).average, 100.7);
});

test('computeStats: empty list gives count 0 and nulls', () => {
  assert.deepEqual(computeStats([]), { count: 0, highest: null, lowest: null, average: null });
});

const rows = [
  { id: 1, date: '2026-09-10', slot: 'morning', value: 90 }, // previous month
  { id: 2, date: '2026-09-30', slot: 'after_dinner', value: 190 }, // previous month
  { id: 3, date: '2026-10-01', slot: 'morning', value: 100 }, // month to date
  { id: 4, date: '2026-10-15', slot: 'after_lunch', value: 160 }, // selected day
  { id: 5, date: '2026-10-15', slot: 'morning', value: 110 }, // selected day
];

test('buildReports splits readings into daily, month-to-date and previous month', () => {
  const r = buildReports(rows, '2026-10-15');

  assert.equal(r.daily.stats.count, 2);
  assert.equal(r.daily.stats.average, 135);
  // Daily readings are listed in slot order (morning before after lunch)
  assert.deepEqual(
    r.daily.readings.map((x) => x.slot),
    ['morning', 'after_lunch']
  );

  assert.deepEqual(r.monthToDate.stats, { count: 3, highest: 160, lowest: 100, average: 123.3 });
  assert.deepEqual(r.previousMonth.stats, { count: 2, highest: 190, lowest: 90, average: 140 });
  assert.deepEqual(r.previousMonth.from, '2026-09-01');
  assert.deepEqual(r.previousMonth.to, '2026-09-30');
});

test('buildReports returns empty stats when a range has no readings', () => {
  const r = buildReports(rows, '2026-10-20');
  assert.equal(r.daily.stats.count, 0);
  assert.equal(r.daily.stats.average, null);
  assert.equal(r.daily.readings.length, 0);
});
