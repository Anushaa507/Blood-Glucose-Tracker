const { test } = require('node:test');
const assert = require('node:assert/strict');
const { validateReadingInput, duplicateSlotMessage } = require('../src/utils/validation');

const TODAY = '2026-11-14';
const valid = { value: 120, slot: 'morning', date: '2026-11-10' };
const messagesFor = (input) => validateReadingInput(input, TODAY).errors.map((e) => e.message);

test('accepts a valid reading', () => {
  const { errors, clean } = validateReadingInput(valid, TODAY);
  assert.equal(errors.length, 0);
  assert.deepEqual(clean, valid);
});

test('accepts a numeric string and converts it to a number', () => {
  const { errors, clean } = validateReadingInput({ ...valid, value: '135' }, TODAY);
  assert.equal(errors.length, 0);
  assert.equal(clean.value, 135);
});

test('value is required', () => {
  for (const value of [undefined, null, '', '   ']) {
    assert.deepEqual(messagesFor({ ...valid, value }), ['Please enter a glucose value.']);
  }
});

test('value must be between 40 and 600', () => {
  const expected = ['Value must be between 40 and 600 mg/dl.'];
  assert.deepEqual(messagesFor({ ...valid, value: 39 }), expected);
  assert.deepEqual(messagesFor({ ...valid, value: 601 }), expected);
  assert.equal(messagesFor({ ...valid, value: 40 }).length, 0);
  assert.equal(messagesFor({ ...valid, value: 600 }).length, 0);
});

test('value must be a whole number', () => {
  const expected = ['Value must be between 40 and 600 mg/dl.'];
  assert.deepEqual(messagesFor({ ...valid, value: 100.5 }), expected);
  assert.deepEqual(messagesFor({ ...valid, value: 'abc' }), expected);
});

test('slot must be one of the four slots', () => {
  assert.deepEqual(messagesFor({ ...valid, slot: undefined }), ['Please choose a time slot.']);
  assert.deepEqual(messagesFor({ ...valid, slot: 'midnight' }), ['Please choose a time slot.']);
});

test('date cannot be in the future', () => {
  assert.deepEqual(messagesFor({ ...valid, date: '2026-11-15' }), ['Date cannot be in the future.']);
  assert.equal(messagesFor({ ...valid, date: TODAY }).length, 0); // today is allowed
});

test('date must be a real calendar date', () => {
  assert.deepEqual(messagesFor({ ...valid, date: '2026-02-30' }), ['Please enter a valid date.']);
  assert.deepEqual(messagesFor({ ...valid, date: '14/11/2026' }), ['Please enter a valid date.']);
  assert.deepEqual(messagesFor({ ...valid, date: undefined }), ['Please choose a date.']);
});

test('reports every problem at once', () => {
  assert.equal(messagesFor({ value: '', slot: '', date: '2099-01-01' }).length, 3);
});

test('duplicate slot message matches the required wording', () => {
  assert.equal(
    duplicateSlotMessage('After lunch'),
    'You already have an After lunch reading for this date.'
  );
  assert.equal(
    duplicateSlotMessage('Morning (fasting)'),
    'You already have a Morning reading for this date.'
  );
});
