const express = require('express');
const db = require('../db');
const config = require('../config');
const { requireAuth } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');
const { SLOTS, SLOT_LABELS, MAX_READINGS_PER_DAY } = require('../utils/constants');
const { todayInTimezone, isValidDateString } = require('../utils/dates');
const { validateReadingInput, MESSAGES, duplicateSlotMessage } = require('../utils/validation');

const router = express.Router();
router.use(requireAuth);

const SLOT_ORDER_SQL = `array_position(ARRAY[${SLOTS.map((s) => `'${s}'`).join(',')}], slot)`;
const COLUMNS = 'id, reading_date AS date, slot, value';

function parsePositiveInt(raw, fallback, max) {
  const n = Number.parseInt(raw, 10);
  if (!Number.isInteger(n) || n < 1) return fallback;
  return Math.min(n, max);
}

// Checks the rules that need the database. Returns an error message or null.
// excludeId: the reading being edited (so it doesn't clash with itself).
async function checkDayRules(userId, date, slot, excludeId = -1) {
  const count = await db.query(
    'SELECT COUNT(*)::int AS n FROM readings WHERE user_id = $1 AND reading_date = $2 AND id <> $3',
    [userId, date, excludeId]
  );
  if (count.rows[0].n >= MAX_READINGS_PER_DAY) return MESSAGES.maxPerDay;

  const clash = await db.query(
    'SELECT 1 FROM readings WHERE user_id = $1 AND reading_date = $2 AND slot = $3 AND id <> $4',
    [userId, date, slot, excludeId]
  );
  if (clash.rows.length) return duplicateSlotMessage(SLOT_LABELS[slot]);

  return null;
}

function validationFailed(res, errors) {
  return res.status(400).json({ error: errors[0].message, errors });
}

// GET /api/readings?page=1&limit=20&date=YYYY-MM-DD
router.get(
  '/',
  asyncHandler(async (req, res) => {
    const page = parsePositiveInt(req.query.page, 1, 1_000_000);
    const limit = parsePositiveInt(req.query.limit, 20, 100);
    const offset = (page - 1) * limit;

    const params = [req.user.id];
    let where = 'user_id = $1';
    if (req.query.date) {
      if (!isValidDateString(req.query.date)) {
        return res.status(400).json({ error: MESSAGES.dateInvalid });
      }
      params.push(req.query.date);
      where += ` AND reading_date = $${params.length}`;
    }

    const total = await db.query(`SELECT COUNT(*)::int AS n FROM readings WHERE ${where}`, params);
    const rows = await db.query(
      `SELECT ${COLUMNS} FROM readings WHERE ${where}
       ORDER BY reading_date DESC, ${SLOT_ORDER_SQL}
       LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
      [...params, limit, offset]
    );

    const totalCount = total.rows[0].n;
    return res.json({
      data: rows.rows,
      page,
      limit,
      total: totalCount,
      totalPages: Math.max(1, Math.ceil(totalCount / limit)),
    });
  })
);

// POST /api/readings   { date, slot, value }
router.post(
  '/',
  asyncHandler(async (req, res) => {
    const today = todayInTimezone(config.timezone);
    const { errors, clean } = validateReadingInput(req.body, today);
    if (errors.length) return validationFailed(res, errors);

    const ruleError = await checkDayRules(req.user.id, clean.date, clean.slot);
    if (ruleError) return res.status(400).json({ error: ruleError });

    try {
      const result = await db.query(
        `INSERT INTO readings (user_id, reading_date, slot, value)
         VALUES ($1, $2, $3, $4) RETURNING ${COLUMNS}`,
        [req.user.id, clean.date, clean.slot, clean.value]
      );
      return res.status(201).json({ reading: result.rows[0] });
    } catch (err) {
      if (err.code === '23505') {
        // Lost a race with another request: the unique constraint caught it.
        return res.status(400).json({ error: duplicateSlotMessage(SLOT_LABELS[clean.slot]) });
      }
      throw err;
    }
  })
);

// PUT /api/readings/:id   { date, slot, value }
router.put(
  '/:id',
  asyncHandler(async (req, res) => {
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isInteger(id)) return res.status(404).json({ error: 'Reading not found.' });

    const today = todayInTimezone(config.timezone);
    const { errors, clean } = validateReadingInput(req.body, today);
    if (errors.length) return validationFailed(res, errors);

    const owned = await db.query('SELECT id FROM readings WHERE id = $1 AND user_id = $2', [
      id,
      req.user.id,
    ]);
    if (!owned.rows.length) return res.status(404).json({ error: 'Reading not found.' });

    const ruleError = await checkDayRules(req.user.id, clean.date, clean.slot, id);
    if (ruleError) return res.status(400).json({ error: ruleError });

    try {
      const result = await db.query(
        `UPDATE readings
         SET reading_date = $1, slot = $2, value = $3, updated_at = now()
         WHERE id = $4 AND user_id = $5
         RETURNING ${COLUMNS}`,
        [clean.date, clean.slot, clean.value, id, req.user.id]
      );
      return res.json({ reading: result.rows[0] });
    } catch (err) {
      if (err.code === '23505') {
        return res.status(400).json({ error: duplicateSlotMessage(SLOT_LABELS[clean.slot]) });
      }
      throw err;
    }
  })
);

// DELETE /api/readings/:id
router.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isInteger(id)) return res.status(404).json({ error: 'Reading not found.' });

    const result = await db.query('DELETE FROM readings WHERE id = $1 AND user_id = $2', [
      id,
      req.user.id,
    ]);
    if (!result.rowCount) return res.status(404).json({ error: 'Reading not found.' });
    return res.status(204).send();
  })
);

module.exports = router;
