const express = require('express');
const db = require('../db');
const config = require('../config');
const { requireAuth } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');
const { todayInTimezone, isValidDateString, previousMonthRange } = require('../utils/dates');
const { buildReports } = require('../utils/reports');
const { MESSAGES } = require('../utils/validation');

const router = express.Router();
router.use(requireAuth);

// GET /api/reports?date=YYYY-MM-DD   (date defaults to today)
// Returns the daily, month-to-date and previous-month reports in one response.
router.get(
  '/',
  asyncHandler(async (req, res) => {
    const today = todayInTimezone(config.timezone);
    const selectedDate = req.query.date || today;

    if (!isValidDateString(selectedDate)) {
      return res.status(400).json({ error: MESSAGES.dateInvalid });
    }
    if (selectedDate > today) {
      return res.status(400).json({ error: MESSAGES.dateFuture });
    }

    // One query covers all three reports: start of previous month -> selected date.
    const { from } = previousMonthRange(selectedDate);
    const result = await db.query(
      `SELECT id, reading_date AS date, slot, value
       FROM readings
       WHERE user_id = $1 AND reading_date BETWEEN $2 AND $3`,
      [req.user.id, from, selectedDate]
    );

    return res.json(buildReports(result.rows, selectedDate));
  })
);

module.exports = router;
