const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../db');
const config = require('../config');
const { requireAuth } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

const router = express.Router();

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const BCRYPT_ROUNDS = 10;

function signToken(userId) {
  return jwt.sign({ sub: String(userId) }, config.jwtSecret, { expiresIn: config.jwtExpiresIn });
}

const publicUser = (row) => ({ id: row.id, name: row.name, email: row.email });

// POST /api/auth/register
router.post(
  '/register',
  asyncHandler(async (req, res) => {
    const name = String(req.body.name || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');

    if (!name) return res.status(400).json({ error: 'Please enter your name.' });
    if (name.length > 100) return res.status(400).json({ error: 'Name is too long.' });
    if (!EMAIL_PATTERN.test(email)) {
      return res.status(400).json({ error: 'Please enter a valid email address.' });
    }
    if (password.length < 8) {
      return res.status(400).json({ error: 'Password must be at least 8 characters.' });
    }

    const existing = await db.query('SELECT id FROM users WHERE email = $1', [email]);
    if (existing.rows.length) {
      return res.status(409).json({ error: 'An account with this email already exists.' });
    }

    const passwordHash = await bcrypt.hash(password, BCRYPT_ROUNDS);
    let created;
    try {
      created = await db.query(
        'INSERT INTO users (name, email, password_hash) VALUES ($1, $2, $3) RETURNING id, name, email',
        [name, email, passwordHash]
      );
    } catch (err) {
      if (err.code === '23505') {
        // Two sign-ups with the same email at the same moment.
        return res.status(409).json({ error: 'An account with this email already exists.' });
      }
      throw err;
    }

    const user = publicUser(created.rows[0]);
    return res.status(201).json({ token: signToken(user.id), user });
  })
);

// POST /api/auth/login
router.post(
  '/login',
  asyncHandler(async (req, res) => {
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');

    if (!email || !password) {
      return res.status(400).json({ error: 'Please enter your email and password.' });
    }

    const result = await db.query(
      'SELECT id, name, email, password_hash FROM users WHERE email = $1',
      [email]
    );
    const row = result.rows[0];
    const ok = row ? await bcrypt.compare(password, row.password_hash) : false;

    if (!ok) return res.status(401).json({ error: 'Invalid email or password.' });

    return res.json({ token: signToken(row.id), user: publicUser(row) });
  })
);

// GET /api/auth/me
router.get(
  '/me',
  requireAuth,
  asyncHandler(async (req, res) => {
    const result = await db.query('SELECT id, name, email FROM users WHERE id = $1', [req.user.id]);
    if (!result.rows.length) return res.status(401).json({ error: 'Account not found.' });
    return res.json({ user: publicUser(result.rows[0]) });
  })
);

module.exports = router;
