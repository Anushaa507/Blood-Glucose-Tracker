// Creates a demo user with about 45 days of sample readings.
// Usage: npm run seed   (run `npm run migrate` first)
// Safe to re-run: the demo user's readings are replaced each time.
const bcrypt = require('bcrypt');
const db = require('../db');
const config = require('../config');
const { SLOTS } = require('../utils/constants');
const { todayInTimezone, addDays } = require('../utils/dates');

const DEMO = { name: 'Demo Patient', email: 'demo@sweety.app', password: 'Demo@1234' };
const DAYS = 45;

// Small deterministic random generator so the demo data is the same every run.
function makeRandom(seed) {
  let state = seed;
  return () => {
    state = (state * 1664525 + 1013904223) % 4294967296;
    return state / 4294967296;
  };
}

// Typical ranges (mg/dl): fasting is lower, after-meal readings are higher.
const RANGES = {
  morning: [82, 132],
  after_breakfast: [115, 190],
  after_lunch: [110, 185],
  after_dinner: [105, 175],
};

async function main() {
  const rand = makeRandom(2026);
  const hash = await bcrypt.hash(DEMO.password, 10);

  const user = await db.query(
    `INSERT INTO users (name, email, password_hash) VALUES ($1, $2, $3)
     ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name, password_hash = EXCLUDED.password_hash
     RETURNING id`,
    [DEMO.name, DEMO.email, hash]
  );
  const userId = user.rows[0].id;
  await db.query('DELETE FROM readings WHERE user_id = $1', [userId]);

  const today = todayInTimezone(config.timezone);
  let inserted = 0;

  for (let i = 0; i < DAYS; i += 1) {
    const date = addDays(today, -i);
    for (const slot of SLOTS) {
      // Skip ~20% of slots so some days have fewer than 4 readings.
      if (rand() < 0.2) continue;
      const [min, max] = RANGES[slot];
      const value = Math.round(min + rand() * (max - min));
      await db.query(
        'INSERT INTO readings (user_id, reading_date, slot, value) VALUES ($1, $2, $3, $4)',
        [userId, date, slot, value]
      );
      inserted += 1;
    }
  }

  console.log(`Seeded ${inserted} readings for ${DEMO.email} (password: ${DEMO.password}).`);
}

main()
  .catch((err) => {
    console.error('Seeding failed:', err.message);
    process.exitCode = 1;
  })
  .finally(() => db.pool.end());
