// Creates the tables. Usage: npm run migrate
const fs = require('fs');
const path = require('path');
const db = require('../db');

async function main() {
  const sql = fs.readFileSync(path.join(__dirname, '../../db/schema.sql'), 'utf8');
  await db.query(sql);
  console.log('Database tables are ready.');
}

main()
  .catch((err) => {
    console.error('Migration failed:', err.message);
    process.exitCode = 1;
  })
  .finally(() => db.pool.end());
