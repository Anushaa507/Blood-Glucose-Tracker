const { SLOTS } = require('./constants');
const { monthToDateRange, previousMonthRange } = require('./dates');

// highest, lowest, average (1 decimal) and count. Everything is null when empty.
function computeStats(values) {
  if (!values.length) {
    return { count: 0, highest: null, lowest: null, average: null };
  }
  const sum = values.reduce((total, v) => total + v, 0);
  return {
    count: values.length,
    highest: Math.max(...values),
    lowest: Math.min(...values),
    average: Math.round((sum / values.length) * 10) / 10,
  };
}

const bySlotOrder = (a, b) => SLOTS.indexOf(a.slot) - SLOTS.indexOf(b.slot);

function inRange(row, { from, to }) {
  return row.date >= from && row.date <= to;
}

/**
 * rows: [{ id, date: 'YYYY-MM-DD', slot, value }] (any order)
 * selectedDate: 'YYYY-MM-DD'
 */
function buildReports(rows, selectedDate) {
  const dailyRange = { from: selectedDate, to: selectedDate };
  const mtdRange = monthToDateRange(selectedDate);
  const prevRange = previousMonthRange(selectedDate);

  const daily = rows.filter((r) => inRange(r, dailyRange)).sort(bySlotOrder);
  const mtd = rows
    .filter((r) => inRange(r, mtdRange))
    .sort((a, b) => (a.date === b.date ? bySlotOrder(a, b) : a.date < b.date ? -1 : 1));
  const prev = rows.filter((r) => inRange(r, prevRange));

  return {
    selectedDate,
    daily: { ...dailyRange, stats: computeStats(daily.map((r) => r.value)), readings: daily },
    monthToDate: { ...mtdRange, stats: computeStats(mtd.map((r) => r.value)), readings: mtd },
    previousMonth: { ...prevRange, stats: computeStats(prev.map((r) => r.value)) },
  };
}

module.exports = { computeStats, buildReports };
