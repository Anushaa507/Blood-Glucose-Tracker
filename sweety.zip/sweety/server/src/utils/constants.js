// Time slots, in the order they happen during the day.
const SLOTS = ['morning', 'after_breakfast', 'after_lunch', 'after_dinner'];

const SLOT_LABELS = {
  morning: 'Morning (fasting)',
  after_breakfast: 'After breakfast',
  after_lunch: 'After lunch',
  after_dinner: 'After dinner',
};

const MIN_VALUE = 40;
const MAX_VALUE = 600;
const MAX_READINGS_PER_DAY = 4;

module.exports = { SLOTS, SLOT_LABELS, MIN_VALUE, MAX_VALUE, MAX_READINGS_PER_DAY };
