const { SLOTS, MIN_VALUE, MAX_VALUE } = require('./constants');
const { isValidDateString } = require('./dates');

const MESSAGES = {
  valueRequired: 'Please enter a glucose value.',
  valueRange: `Value must be between ${MIN_VALUE} and ${MAX_VALUE} mg/dl.`,
  slotRequired: 'Please choose a time slot.',
  dateRequired: 'Please choose a date.',
  dateInvalid: 'Please enter a valid date.',
  dateFuture: 'Date cannot be in the future.',
  maxPerDay: 'You can add only 4 readings per day.',
};

// "You already have an After lunch reading for this date." / "...a Morning reading..."
const duplicateSlotMessage = (slotLabel) => {
  const name = slotLabel.replace(/\s*\(.*\)$/, ''); // "Morning (fasting)" -> "Morning"
  const article = /^[aeiou]/i.test(name) ? 'an' : 'a';
  return `You already have ${article} ${name} reading for this date.`;
};

/**
 * Validates the fields of a reading (value, slot, date).
 * `today` is "YYYY-MM-DD" in the app timezone.
 * Returns { errors: [{ field, message }], clean: { value, slot, date } }.
 * (The "one per slot" and "max 4 per day" rules need the database, so they
 * are checked in the route.)
 */
function validateReadingInput(input, today) {
  const errors = [];
  const { value: rawValue, slot, date } = input || {};

  // --- value ---
  let value;
  const isEmpty =
    rawValue === undefined ||
    rawValue === null ||
    (typeof rawValue === 'string' && rawValue.trim() === '');
  if (isEmpty) {
    errors.push({ field: 'value', message: MESSAGES.valueRequired });
  } else {
    value = typeof rawValue === 'number' ? rawValue : Number(String(rawValue).trim());
    if (!Number.isInteger(value) || value < MIN_VALUE || value > MAX_VALUE) {
      errors.push({ field: 'value', message: MESSAGES.valueRange });
    }
  }

  // --- slot ---
  if (!slot) {
    errors.push({ field: 'slot', message: MESSAGES.slotRequired });
  } else if (!SLOTS.includes(slot)) {
    errors.push({ field: 'slot', message: MESSAGES.slotRequired });
  }

  // --- date ---
  if (!date) {
    errors.push({ field: 'date', message: MESSAGES.dateRequired });
  } else if (!isValidDateString(date)) {
    errors.push({ field: 'date', message: MESSAGES.dateInvalid });
  } else if (date > today) {
    errors.push({ field: 'date', message: MESSAGES.dateFuture });
  }

  return { errors, clean: { value, slot, date } };
}

module.exports = { validateReadingInput, MESSAGES, duplicateSlotMessage };
