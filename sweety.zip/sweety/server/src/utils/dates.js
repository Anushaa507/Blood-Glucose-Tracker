// Date helpers. Dates are always plain "YYYY-MM-DD" strings, which compare
// correctly with ordinary string comparison (e.g. '2026-10-01' < '2026-10-15').

const pad = (n) => String(n).padStart(2, '0');
const format = (y, m, d) => `${y}-${pad(m)}-${pad(d)}`;

function isValidDateString(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [y, m, d] = value.split('-').map(Number);
  const date = new Date(Date.UTC(y, m - 1, d));
  return date.getUTCFullYear() === y && date.getUTCMonth() === m - 1 && date.getUTCDate() === d;
}

// Today's date ("YYYY-MM-DD") in the given IANA timezone.
function todayInTimezone(timeZone, now = new Date()) {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(now);
}

function addDays(dateString, days) {
  const [y, m, d] = dateString.split('-').map(Number);
  const date = new Date(Date.UTC(y, m - 1, d + days));
  return format(date.getUTCFullYear(), date.getUTCMonth() + 1, date.getUTCDate());
}

// 1st of the selected month -> the selected date.
function monthToDateRange(dateString) {
  const [y, m] = dateString.split('-').map(Number);
  return { from: format(y, m, 1), to: dateString };
}

// The whole calendar month before the selected date's month.
function previousMonthRange(dateString) {
  let [y, m] = dateString.split('-').map(Number);
  m -= 1;
  if (m === 0) {
    m = 12;
    y -= 1;
  }
  const lastDay = new Date(Date.UTC(y, m, 0)).getUTCDate(); // day 0 of next month = last day of m
  return { from: format(y, m, 1), to: format(y, m, lastDay) };
}

module.exports = {
  isValidDateString,
  todayInTimezone,
  addDays,
  monthToDateRange,
  previousMonthRange,
};
