const { Pool, types } = require('pg');
const config = require('./config');

// Return DATE columns as plain "YYYY-MM-DD" strings instead of JS Date objects,
// which avoids timezone shifts.
types.setTypeParser(1082, (value) => value);

const pool = new Pool({ connectionString: config.databaseUrl });

module.exports = {
  query: (text, params) => pool.query(text, params),
  pool,
};
